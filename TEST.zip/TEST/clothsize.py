import os
import numpy as np
import tensorflow as tf
import pandas as pd

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

data = pd.read_csv("C:\\Users\\82104\\PycharmProjects\\pythonProject\\TEST\\data\\clothsize.csv")
data = data.dropna()

ydata = data["size"].map({"S": 0, "M": 1, "L": 2, "XL": 3, "XXS": 4, "XXL": 5, "XXXL": 6})
xdata = data[["weight", 'age', 'height']]

xdata = np.array(xdata)
ydata = np.array(ydata)

model = tf.keras.models.Sequential([tf.keras.layers.Dense(64, activation='relu'),
                                    tf.keras.layers.Dense(128, activation='relu'),
                                    tf.keras.layers.Dense(256, activation='relu'),
                                    tf.keras.layers.Dropout(0.2),
                                    tf.keras.layers.Dense(64, activation='relu'),
                                    tf.keras.layers.Dense(1)
                                    ])
opt = tf.keras.optimizers.Adam(learning_rate=0.001)
model.compile(optimizer=opt, loss='mse', metrics=['accuracy'])
model.fit(xdata,ydata,epochs=100)
result = model.evaluate(xdata,ydata,verbose=2)
pred = model.predict([82,22,183])

print(result, pred)